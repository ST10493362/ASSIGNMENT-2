package za.ac.iie.assignment2

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Question : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_question)

        val questions = arrayOf(
            "Nelson Mandela was president in 1994",
            "World War I ended in 1945",
            "The Great Wall of China is visible from space",
            "The pyramids are in Egypt",
            "The Berlin Wall fell in 1989"
        )

        val answers = arrayOf(true, false, false, true, true)
        var currentQuestion = 0
        var score = 0

        var questionText: TextView
        var feedbackText: TextView
        var trueButton: Button
        var falseButton: Button
        var nextButton: Button



        questionText = findViewById(R.id.txtQuest)
        feedbackText = findViewById(R.id.txtFeedb)
        trueButton = findViewById(R.id.btnTrue)
        falseButton = findViewById(R.id.btnFalse)
        nextButton = findViewById(R.id.btnNext)

        fun loadQuestion() {
            questionText.text = questions[currentQuestion]
            feedbackText.text = ""
            trueButton.isEnabled = true
            falseButton.isEnabled = true
            nextButton.isEnabled = false
        }

        loadQuestion()
        fun checkAnswer(userAnswer: Boolean) {

            val correct = answers[currentQuestion] == userAnswer
            if (correct) {
                feedbackText.text = "Correct!"
                score++

            } else {

                feedbackText.text = "Incorrect!"
            }
            trueButton.isEnabled = false
            falseButton.isEnabled = false
            nextButton.isEnabled = true
        }


        trueButton.setOnClickListener { checkAnswer(true) }
        falseButton.setOnClickListener { checkAnswer(false) }

        nextButton.setOnClickListener {
            currentQuestion++
            if (currentQuestion < questions.size) {
                loadQuestion()
            } else {
                val intent = Intent(this, Scores::class.java)
                intent.putExtra("score", score)
                intent.putExtra("Questions", questions.size)
                startActivity(intent)
                finish()
            }
        }
    } }

















































